package chatdonkey.core;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The stock contents of {@code config/chatdonkey/lines.json} (SPEC.md
 * section 8).
 *
 * <p>Voice: an Animal Crossing villager who happens to be a donkey and happens
 * to be furious with you. Sing-song, over-punctuated, hugely self-important,
 * and completely convinced it is doing you a favour. Short -- these fire every
 * seven seconds, so anything longer than two sentences reads as spam.
 *
 * <p>It never swears and never references a real person (SPEC.md section 8).
 * It also never threatens the player directly -- not because it is harmless
 * (section 1, revised: an interruption is allowed to get you killed) but
 * because the comedy is that it is oblivious to the trouble it causes. A donkey
 * that knows it is endangering you is a villain; one that is simply desperate
 * to discuss your choices while a creeper approaches is funny.
 */
public final class DefaultLines {

    private DefaultLines() {}

    public static Map<String, List<String>> pools() {
        Map<String, List<String>> pools = new LinkedHashMap<>();

        pools.put("names", List.of(
                "Duncan",
                "Señor Burro",
                "The Auditor",
                "Clopsworth",
                "Muffinhoof",
                "Sir Nibbles",
                "Bramble",
                "Hee-Haw Harold",
                "Persimmon",
                "Doreen"));

        pools.put("lecture.open", List.of(
                "Oh! OH! There you are! I have been looking absolutely EVERYWHERE, hoofball!",
                "Yoo-hoo! Don't mind me. I'm just going to stand right here. Forever! Hee-haw!",
                "Hiiii! Guess who came all this way to discuss your choices! It's me. I'm who.",
                "Well, well, WELL. Fancy running into you! Out here! Where I followed you!",
                "Knock knock! It's a donkey. That's the whole joke and I think it's wonderful.",
                "Ohmygosh, HI! I have so much to say and NONE of it is optional!",
                "Excuse me! Excuse me. EXCUSE me. Thank you. Now then. Let's begin.",
                "Don't bother running, sport! I'm slow, but I am extremely committed. Clop clop!"));

        pools.put("lecture.during", List.of(
                "And ANOTHER thing! ...Hmm. I've forgotten it. It was scathing, though!",
                "You know what your problem is? You don't listen. Also everything else!",
                "I'm not mad, hoofball. I'm disappointed. And a little mad. Hee-haw!",
                "Back in MY day we walked everywhere. I still do! Mostly right behind you!",
                "This is a safe space. For me. To criticize you. Isn't that just lovely?",
                "Are you even taking notes?! I'll wait. ...I'm waiting. ...Still waiting!",
                "Oh, sure, keep doing that. It's your afternoon! I'm merely narrating it.",
                "I've seen your house, by the way. We should talk about your house, sport.",
                "Do you ever stop and think? No? Wellllll. That explains a great deal!",
                "I'm helping! This IS helping! You'll thank me later. Probably never!",
                // Folded in from the old Clingy event, which is now part of this one.
                "Am I too close? ...I'll take that as a no. Scooting closer!",
                "Personal space is a SOCIAL CONSTRUCT, hoofball!",
                "I can hear you breathing. That's how close we are. Isn't that lovely?",
                "Whatever you're doing, I'm doing it too. From very nearby!"));

        /*
         * Fired when the player outruns the lecture and it simply appears on top
         * of them. Inherited from the old Clingy event, which is now the close
         * end of this one.
         */
        pools.put("lecture.teleport", List.of(
                "Missed me?! I missed YOU! You can't just LEAVE, sport!",
                "Ta-daaa! Distance is a myth! I've disproved it! Personally!",
                "Where'd you GO?! Oh — there you are. Found you! Always will!",
                "Nice try, hoofball! I'm faster than legs. I don't make the rules!",
                "You RAN. From ME. We'll discuss that. Up close!",
                "As I was SAYING before you sprinted off like a coward —"));

        // Shared pools -- any behavior can draw from these.

        pools.put("hit", List.of(
                "OW! You hit ME! Right in my FEELINGS!",
                "Chat saw that. Chat. Saw. That.",
                "I'm not moving until you say you're sorry. I mean it!",
                "Rude! RUDE! And after everything I've done for you!",
                "That's going in my report, hoofball. I keep a report!",
                "Violence?! In front of my salad?! I don't even have a salad!",
                "Ohhh, so THAT'S how it is. Noted. Noted forever!",
                "You can't hurt me. You can only disappoint me. And you HAVE!"));

        // Shared exit pools. Any behavior with no send-off of its own for these
        // two endings falls back here, which is why only Lecture bothers to
        // write its own: a donkey's reaction to a diamond, or to being smacked,
        // barely depends on what it was doing beforehand.
        //
        // There is deliberately NO shared `exit_waited`. Running out the clock
        // is the ending every behavior reaches, so each one should have
        // something of its own to say -- and the coverage test enforces it.

        pools.put("exit_bribed", List.of(
                "Ohhh, a DIAMOND! Well! Why didn't you SAY so! Mwah!",
                "For me?! You shouldn't have! You really shouldn't have! Byeee!",
                "A gift! I accept! I'm leaving! Everyone wins! Especially me!",
                "Bribery! My FAVOURITE kind of conversation. Toodle-oo, sport!",
                "Shiny! Yes! Fine! You've bought your afternoon back. Hee-haw!"));

        pools.put("exit_grudge", List.of(
                "You're welcome for the company. That's all you're getting.",
                "No gift for hitters. I have STANDARDS, hoofball!",
                "I was going to give you something. Was!",
                "Don't talk to me. Don't even LOOK at me. Good DAY!",
                "Hmmph! I'm taking my rocks and going home!"));

        pools.put("deny", List.of(
                "You can't ride me. We're not there yet, sport.",
                "Hands to yourself! I'm a professional!",
                "A saddle? A SADDLE? Read the room, hoofball!",
                "That's not going to work on me. Nothing works on me!",
                "Oh, is that for me? ...It isn't. I can tell. Hee-haw.",
                "No no no. I'm the one doing things TO YOU. That's the arrangement!"));

        pools.put("lecture.exit_bribed", List.of(
                "Ohhh, a DIAMOND! Well! Why didn't you say so! Mwah!",
                "For me?! You shouldn't have! You really shouldn't have, it's so shiny!",
                "A gift! I accept. I'm leaving. This is what class looks like, sport!",
                "Bribery! My FAVOURITE kind of conversation! Toodle-oo!",
                "Well now I feel bad. ...No, wait. That passed. Byeee!",
                "You've bought yourself an afternoon. Spend it wisely, hoofball!"));

        pools.put("lecture.exit_grudge", List.of(
                "You're welcome for the company. That's all you're getting.",
                "No gift for hitters. I have STANDARDS, hoofball.",
                "I was going to give you something. Was.",
                "Hmmph! I'm taking my cobblestone and going home!",
                "Don't talk to me. Don't even LOOK at me. Good DAY!",
                "I hope you think about this. I certainly will!"));

        pools.put("lecture.exit_waited", List.of(
                "Welp! That's my whole speech. I feel GREAT. You look worse. Hee-haw!",
                "Anyway! I've said what I came to say, and I said it beautifully.",
                "I'll leave you to it! Whatever it is. It looked unpromising, hoofball!",
                "Okay, byeeee! Think about what I said. All of it. There'll be a quiz!",
                "Same time next week? Don't answer, it wasn't a question. Clop clop!",
                "Whew! Lecturing is exhausting. You're welcome for the company, sport!",
                "Here, take this. It isn't much! Neither was your effort today. Hee-haw!",
                "I'm off to go bother someone with better hobbies. Toodle-oo!"));

        // The Food Critic: follows you demanding a carrot, and will not shut up
        // about it until it gets one.

        pools.put("foodcritic.open", List.of(
                "Ohmygosh, HI! Quick question! Do you have a carrot? Be honest!",
                "Excuse me! EXCUSE me. I smell a carrot. Somewhere. On you. Hand it over!",
                "Hiiii! I'm STARVING and you're RIGHT THERE. Do the math, hoofball!",
                "Well hello! I don't want to be a bother, but I do want a carrot!",
                "Yoo-hoo! I'm conducting a survey! The survey is: give me a carrot!",
                "You look like someone with a carrot. Don't disappoint me, sport!"));

        pools.put("foodcritic.during", List.of(
                "Carrot. Carrot? Carrot! ...I can do this all day, hoofball!",
                "I'm not begging. I'm ASKING. Loudly. Repeatedly. Forever!",
                "A carrot would fix this. Just saying! Just putting that out there!",
                "Do you know what I HAVEN'T had recently? Take a wild guess!",
                "I've eaten grass today. GRASS. And you have POCKETS!",
                "I'd give YOU a carrot. If I had one. Which I don't. Hint hint!",
                "Golden ones exist, you know. Just a fun fact! No pressure! ...Some pressure.",
                "My stomach is writing a strongly worded letter. To you!"));

        pools.put("foodcritic.exit_satisfied", List.of(
                "MMPH! Oh, that's the stuff. You're alright, hoofball. You're ALRIGHT!",
                "*crunch* ...Mm! Mmhm! Yes! Acceptable! Barely! Delicious!",
                "Ohhh, thank you thank you THANK you! Take this, I insist!",
                "A carrot! An actual carrot! I take back almost everything!",
                "You've made a friend today, sport. A loud one. Byeee!"));

        pools.put("foodcritic.exit_golden", List.of(
                "A GOLDEN one?! For ME?! I'm going to cry! I'm crying! Hee-haw!",
                "Oh my stars. Oh my STARS. You didn't have to! You DIDN'T! But you DID!",
                "This is the best day of my entire life and I've had SEVERAL. Take this!",
                "GOLDEN?! I'm telling everyone. EVERYONE. Here, you've earned it!"));

        pools.put("foodcritic.exit_waited", List.of(
                "Nothing?! NOTHING? Fine! FINE. I'll starve. Dramatically. Elsewhere!",
                "Not one carrot. I'll remember this, hoofball. Here, take your rocks.",
                "Well! I've never been so ignored in my life. Hee-haw. Goodbye!",
                "I'm going to go find someone with SNACKS. Don't follow me!",
                "You had NOTHING. Who leaves home with nothing? Unbelievable!"));

        pools.put("foodcritic.exit_bribed", List.of(
                "A diamond?! I asked for a CARROT. But... okay. Yes. Fine. Deal!",
                "That's not a carrot. That's much better. I'll allow it! Mwah!",
                "You can't eat a diamond, hoofball. I'll manage. Somehow. Byeee!",
                "Ooooh, SHINY. I forgive you for the carrot thing. Toodle-oo!"));

        pools.put("foodcritic.exit_grudge", List.of(
                "No carrot AND you hit me?! Absolutely not. Nothing for you!",
                "I asked for a carrot and got a smack. I'm keeping the rocks!",
                "You're the worst waiter I've ever had. NO tip. Good DAY!"));

        // Roadblock: plants itself directly in your path, over and over.

        pools.put("roadblock.open", List.of(
                "Whoa there! Where do YOU think you're going, hoofball?",
                "Ah-ah-AH! This way's closed. By me. I'm the closure!",
                "Halt! Who goes there! ...It's you. I know it's you. Halt anyway!",
                "Oh, were you walking? Were you? How INCONVENIENT for you!",
                "You shall not pass! ...Is that taken? It felt taken. Regardless!",
                "New rule: this spot is mine now. And this one. And that one!"));

        pools.put("roadblock.during", List.of(
                "Nope! Still here! Try going around. I'll be there too!",
                "Ooh, a feint! Very clever. I saw it. I'm ahead of you. Literally!",
                "This is the most productive I've felt in WEEKS, sport!",
                "Where are we going? I'll go first. I'm always going first!",
                "You're very determined. It's admirable! It won't work, but it's admirable!",
                "I could do this all day. I have nowhere to be. Except here. Hee-haw!",
                "Left? Right? Doesn't matter! I've been to both. Just now!",
                "Am I in the way? I certainly hope so. That's the whole idea!"));

        pools.put("roadblock.exit_waited", List.of(
                "Alright, you may pass. You've earned it. Barely. Hee-haw!",
                "The road is yours again, hoofball. Use it wisely!",
                "I've decided you're allowed to go places. Aren't you lucky!",
                "Right! That's enough civil engineering for one day. Toodle-oo!"));

        // Serenade: circles you singing. Loudly. Badly.

        pools.put("serenade.open", List.of(
                "Ahem! AHEM! Gather round! Well — you'll do. A song! For you!",
                "I've written something. It's about you. It's not flattering. Enjoy!",
                "Hit it! ...There's no band. I'm the band. HEE-HAW!",
                "Don't move! This is a PERFORMANCE and you are the AUDIENCE!"));

        pools.put("serenade.during", List.of(
                "♪ Ohhhh, you were walking, and I was watchiiiing ♪",
                "♪ Your face! Your face! It's a face I've seeeeen! ♪",
                "♪ I know a guy, he's got no plan, that guy is you, hee-haw ♪",
                "♪ La la LAAAA — that's the chorus, sing along! ...Or don't! ♪",
                "♪ Nobody asked for thiiiiis, and yet, here we ARRRE ♪",
                "♪ Braaaaaay. That one's instrumental. It's my best work ♪",
                "♪ Verse seventeen! There are forty! ♪",
                "♪ You could leave, but I would follow, singiiiing ♪"));

        pools.put("serenade.exit_waited", List.of(
                "Thank you! THANK you! No, please, hold your applause. ...Please hold it.",
                "And THAT'S how it's done. Tips accepted. Here, I'll go first!",
                "My throat! My poor throat. Worth it. Every note. Toodle-oo!",
                "I'll be here all week. I won't be. But I'll SAY it. Byeee!"));

        // False Alarm: sprinting circles, screaming about nothing.

        pools.put("falsealarm.open", List.of(
                "CREEPER! CREEPER!! ...Somewhere! I heard one! RUN! Or don't!",
                "LAVA! LAVA!! ...No, wait. That's a puddle. STILL! Be alert!",
                "THE VOID! IT'S COMING! It's always coming! Technically!",
                "EVERYBODY PANIC! You! You're everybody! PANIC!",
                "I SAW SOMETHING! It was big! Or small! It was SOMETHING!"));

        pools.put("falsealarm.during", List.of(
                "IT'S BEHIND YOU! ...It's not. But it COULD be! Stay sharp!",
                "AAAAAA! ...Sorry. False alarm. AAAAAA AGAIN!",
                "Don't look! DON'T LOOK! ...Okay, look. Nothing. TERRIFYING!",
                "This is fine! THIS IS FINE! IS IT?! I DON'T KNOW!",
                "Structural collapse! Of what? UNCLEAR! Keep moving!",
                "I've done the math and we have SECONDS! Of what? SECONDS!",
                "SOMETHING IS DEFINITELY HAPPENING SOMEWHERE!"));

        pools.put("falsealarm.exit_waited", List.of(
                "False alarm! Phew! You're welcome for the vigilance, hoofball!",
                "Crisis averted! By me! Mostly by there being no crisis!",
                "Well, we survived. Barely. I'll take the credit. Toodle-oo!",
                "See? Nothing! And you were SO calm about it. Suspiciously calm!"));

        // Burrs: opens his coat in your face and demands you groom him.

        pools.put("burrs.open", List.of(
                "BURRS! I'm FULL of them! You have thumbs — USE THEM, hoofball!",
                "Emergency! Grooming emergency! Look at the state of me!",
                "I can't reach! I've TRIED! Do you know how long I've tried?!",
                "Hold still. YOU hold still. I'm the one with the problem here!",
                "Right! You're on burr duty. Congratulations on the promotion!"));

        pools.put("burrs.during", List.of(
                "Faster! No, gentler! No — FASTER but GENTLER, sport!",
                "Ooh. Ooooh. That's the spot. Don't stop. Never stop!",
                "You're doing fine. FINE. Not great. Fine!",
                "My mother used to do this. She was better at it. No offence!",
                "Is this the best you can do? ...Don't answer that, hoofball."));

        pools.put("burrs.refind", List.of(
                "Oh! OH! There's another one! Where do they COME from?!",
                "Wait wait wait — found one! Found another one! Sorry!",
                "Hee-haw! Fresh burr! Straight from the bush! Get it, get it!",
                "Don't panic. But I've located a NEW one. Panic slightly!",
                "Ohhh, that's embarrassing. There's more. There's so much more."));

        pools.put("burrs.reopen", List.of(
                "Where are you GOING?! I'm not done being groomed, hoofball!",
                "Ah-ah-AH! We had a deal! I never said the deal was over!",
                "You can't just CLOSE me! Rude! Look at my coat! LOOK AT IT!",
                "Nope! Back in. Chop chop. The burrs aren't going anywhere!",
                "Oh, we're doing this again? Fine! I have all afternoon, sport!"));

        pools.put("burrs.exit_satisfied", List.of(
                "MAGNIFICENT! I'm gorgeous! I'm a NEW DONKEY! Take this, you earned it!",
                "Not one burr left! You've got a gift, hoofball. A small one. Here!",
                "Ohhh, I feel LOVELY. Look at me go! Thank you, sport! Byeee!",
                "Perfect. PERFECT. I take back most of what I said about you!"));

        pools.put("burrs.exit_waited", List.of(
                "Fine! FINE. I'll live with them. Forever. Alone. Thanks for nothing!",
                "You gave up! On ME! Here, have these back — I don't want them either.",
                "Half a job is worse than no job, hoofball. Remember that!",
                "I'll find someone with more patience. And better hands. Toodle-oo!"));

        // The Sweet Tooth: apples, and ideally the gold ones.

        pools.put("sweettooth.open", List.of(
                "You there! Apple. Now. I've had a DAY and I need an apple!",
                "Ohhh I can smell fruit. Don't lie to me, hoofball. Hand it over!",
                "An apple! Just one! I'm not a monster! ...I'm slightly a monster!",
                "Hello! Quick thing! Apples. Do you have. Any. It's urgent!"));

        pools.put("sweettooth.during", List.of(
                "An apple a day keeps the donkey away! That's the deal! Take it!",
                "Do you know what's better than an apple? A GOLD one. Just saying!",
                "I'm wasting away. Look at me. LOOK. Wasting!",
                "Crunchy. Sweet. Round. I'm describing an apple. In case you forgot!",
                "I'd get one myself but I have no thumbs and no ambition!"));

        pools.put("sweettooth.exit_satisfied", List.of(
                "*CRUNCH* Ohhh that's the good stuff. Here, take this, you lovely thing!",
                "Mmmm! Apple! The people's fruit! You're alright, hoofball!",
                "Delicious. Adequate. DELICIOUS. Take your reward and go!"));

        pools.put("sweettooth.exit_golden", List.of(
                "A GOLDEN apple?! Are you a KING? Am I meeting a KING? Take this!",
                "GOLD! For ME! I'll never forget this. I will, but I mean it now!",
                "Oh my days. Oh my DAYS. Here, have a diamond, I insist, GO!"));

        pools.put("sweettooth.exit_waited", List.of(
                "No apple. NO APPLE. I'll remember this at Christmas, hoofball!",
                "Fine! I'll eat grass. Like an ANIMAL. Which I am! That's not the POINT!",
                "You had nothing. Nothing! What do you even carry? Toodle-oo!"));

        // The Bookworm: paperwork, and it takes itself very seriously.

        pools.put("bookworm.open", List.of(
                "Excuse me! I require a book. For reasons. Official reasons!",
                "STOP. Do you have literature? Any literature? I'm not fussy!",
                "I'm writing my memoirs and I've run out of paper. Tragic, really!",
                "A book! Quickly! The thought is escaping as we speak!"));

        pools.put("bookworm.during", List.of(
                "I read, you know. I'm very well read. I've read a book. Once.",
                "An ENCHANTED one would be better. I'd sound so clever. Just a thought!",
                "How am I meant to document your failings without paper, hoofball?",
                "Chapter one: 'They Had No Book.' It's a short chapter. It's about you!",
                "I've got so much to say and nowhere to write it. This is a CRISIS!"));

        pools.put("bookworm.exit_satisfied", List.of(
                "A book! Now I can write down everything you've done. Here, payment!",
                "Ohh, lovely paper. Crisp. Blank. Like your expression! Take this!",
                "Excellent! I'll get started immediately. Chapter one: you're alright."));

        pools.put("bookworm.exit_golden", List.of(
                "ENCHANTED?! I'll be the cleverest donkey in the field! Take a diamond!",
                "It GLOWS! I can't read it but it GLOWS! Magnificent! This is yours!",
                "Oh, you magnificent creature. I'm going to be UNBEARABLE now. Byee!"));

        pools.put("bookworm.exit_waited", List.of(
                "Not one book. In this ECONOMY of ideas! Disgraceful, hoofball!",
                "I'll just have to remember it all. I won't. It's gone. Thanks a lot!",
                "Illiterate company. That's what I keep. Rocks for you. Good day!"));

        // The Magpie: shiny things, and absolutely no shame about it.

        pools.put("magpie.open", List.of(
                "SHINY! You've got something shiny! I saw it! Give it here!",
                "Ooooh. Ooooh! Metal! Is that metal? Show me the metal, hoofball!",
                "Stop right there. That glint. THAT GLINT. I want it. Please. Now.",
                "I collect things! Shiny things! You have shiny things! Do the maths!"));

        pools.put("magpie.during", List.of(
                "Iron's fine. Iron's FINE. Gold would be better. GOLD, sport!",
                "I'm not greedy. I just want everything you have that sparkles!",
                "One ingot. ONE. Then I'll go. Probably. Ninety percent!",
                "Look at it glinting in there. It's practically ASKING to be mine!",
                "My collection is my whole personality and it is currently EMPTY!"));

        pools.put("magpie.exit_satisfied", List.of(
                "MINE! It's mine now! Beautiful! Here, have some rocks. Fair trade!",
                "Ooooh, look at it. LOOK at it. Worth every second of your time!",
                "Into the collection it goes! You've made a donkey very happy!"));

        pools.put("magpie.exit_golden", List.of(
                "GOLD! ACTUAL GOLD! I'm going to faint! Take this before I do!",
                "You beautiful, generous, shiny-having creature! A diamond for you!",
                "I'm rich! I'm RICH! Well — I have one. But I HAVE ONE! Byeee!"));

        pools.put("magpie.exit_waited", List.of(
                "Nothing shiny. Nothing at ALL. What a bleak little pocket you have!",
                "I've seen brighter rocks. I AM giving you rocks. Think about that!",
                "Hoarding it, are you? Fine! I'll find someone with taste. Toodle-oo!"));

        // The Alchemist: hands back double whatever raw material you give it.

        // The Magician: will NOT stop trying to show you his one magic trick.

        pools.put("magician.open", List.of(
                "Hey! HEY! You wanna see a magic trick? You do. Everybody does!",
                "Oh, oh, oh — pick a rock! ANY rock! No, don't tell me. Just GIVE it me!",
                "Step right up! One trick! It's the only one I know but it's a GOOD one!",
                "I been PRACTISING. Hand me somethin' raw and prepare to be AMAZED!",
                "Watch this. WATCH. THIS. ...You have to give me a rock first. But WATCH!"));

        pools.put("magician.during", List.of(
                "Raw stuff only! Rocks, ore, ingots! Don't hand me your BOOTS, hoofball!",
                "Nothing crafted! The magic don't work on stuff that's already been ruined!",
                "C'mon, c'mon, anything! Cobble! I'll do it with cobble! I'm not proud!",
                "The trick is in the teeth. That's all I'm sayin'. That's the whole secret!",
                "Is it magic? Is it? ...It might not be magic. But is it? IT MIGHT BE!",
                "I'm a MAGICIAN! Well — I'm a donkey. But TODAY I'm a magician!",
                "You're gonna love this. Everybody loves this. Nobody's seen it yet!"));

        pools.put("magician.exit_satisfied", List.of(
                "*CHOMP* ...TA-DAAAAA! TWO of 'em! Where'd the other one come from?! MAGIC!",
                "BOOM! Doubled! Did you see that? You didn't blink, did you? TELL me you saw!",
                "AND THE CROWD GOES WILD! ...There's no crowd. It's just you. STILL COUNTS!",
                "Ohhh I nailed it! I NAILED it! Take 'em both, I'm on a ROLL!",
                "Twice as much! No mirrors! No wires! No idea how! TA-DA, hoofball!"));

        pools.put("magician.exit_grudge", List.of(
                "You HIT the magician! Magicians are SACRED! Here, take your one rock.",
                "No trick for hitters. That's showbusiness, hoofball. Exactly what you gave me.",
                "The magic runs on APPLAUSE, and you gave me a SMACK. Here. Just the one."));

        pools.put("magician.exit_waited", List.of(
                "Nothin'?! I had an ACT prepared! I had PATTER! Have some rubble instead!",
                "A whole inventory and not one honest rock. You're a tough crowd, sport!",
                "Fine! FINE. I'll take my act somewhere they APPRECIATE a doubled pebble!",
                "You'll regret this. Someday you'll need a rock doubled and I'll be GONE!"));

        return pools;
    }
}
